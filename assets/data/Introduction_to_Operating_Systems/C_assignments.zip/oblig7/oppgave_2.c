#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

// Her lager jeg et globalt flagg som indikerer om barneprosessen har avsluttet
volatile sig_atomic_t deadChild = 0;

// Denne funksjonen blir kalt i hver iterasjon fra barneprosessen
void childsPlay(int sig) {
    printf("Slutt å mase, din lille sa**n.\n");
}

// Denne funksjonen blir kalt når barneprosessen avsluttes
void handleChildExit(int sig) {
    int status;
    wait(&status);
    deadChild = 1;
}

int main()
{
    pid_t child;
    char message[100];

    signal(SIGUSR1, childsPlay);
    signal(SIGCHLD, handleChildExit);

    // Skaper en barneprosesses
    child = fork();

    if (child == 0)
    {
        while(1) {
            scanf("%s", message);

            if (strcmp(message, "quit") != 0) {
                kill(getppid(), SIGUSR1);
                usleep(200000);
            } else {
                exit(0);
            }
        }
    } else {
        // Foreldreprosessen er i en vente loop
        while (!deadChild) {
            pause();  // Venter på signal (enten SIGUSR1 eller SIGCHLD)

            // Foreldreprosessen vil avslutte når SIGCHLD signalet er mottatt
        }

        printf("Nå er det fasen meg nok!\n");
    }

    return 0;
}
