#include <stdio.h>
#include <pthread.h>

//Legger til mutex som en variabel
pthread_mutex_t mutex;

int count = 0;

void *increase()
{
    //Låser variabelen count frem til iterasjonen er ferdig.
    pthread_mutex_lock(&mutex);
	int i;
	for(i = 0; i < 1e8; ++i)
		count++;
    //Låser opp variabelen etter at iterasjon er fullført.
    pthread_mutex_unlock(&mutex);
}

void *decrease()
{
    //Låser variabelen count frem til iterasjonen er ferdig.
    pthread_mutex_lock(&mutex);
	int i;
	for(i = 0; i < 1e8; ++i)
		count--;
    //Låser opp variabelen etter at iterasjon er fullført.
    pthread_mutex_unlock(&mutex);
}

int main()
{
	pthread_t thread1, thread2;

    //Initialiserer mutex.
    pthread_mutex_init(&mutex, NULL);

	pthread_create(&thread1, NULL, increase, NULL);
    pthread_create(&thread2, NULL, decrease, NULL);
	
	pthread_join(thread1, NULL);
	pthread_join(thread2, NULL);

    // Terminerer mutex når tråder er ferdig kjørt.
    pthread_mutex_destroy(&mutex);

	printf("count = %d\n", count);
}