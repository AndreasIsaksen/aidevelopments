#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define MAX_WAIT 2000000

pthread_mutex_t mutex;
pthread_cond_t cond;

// Legger på en global variable som skal brukes til å telle
// antall blokkerte tråder
int block_count = 0;

void *terningkast(void *nr)
{
	while(1)
	{
		int terning = rand()%6 + 1;

		pthread_mutex_lock(&mutex);
// Gjorde om funksjoens struktur til en if test
        if(terning == 1) {
            // Her adderes en verdi til block_count for hver tråd
            // som får terningkast 1.
            block_count++;
            // Tråd printer før den stopper, slik at man kan se når alle
            // tråder er blitt blokkert.
            printf("Tråd %3ld -> %d (%d)\n", (long) nr, terning, block_count);
            // Tråd blokkeres å venter på et start signal.
            pthread_cond_wait(&cond, &mutex);
            pthread_mutex_unlock(&mutex);
            // Når tråd mottar signal trekker den i fra en verdi på block_count
            block_count--;
        } else if (terning == 6) {
            // Tråder med terningkast 6 sender signal om å starte en tråd i blokk kø
            pthread_cond_signal(&cond);
            // Printer ut med et antall tråder i den nåværende køen
            printf("Tråd %3ld -> %d (%d)\n", (long) nr, terning, block_count);
            pthread_mutex_unlock(&mutex);
        } else {
            // Den originale handlingen som kjører for terningkast mellom 2-5
            printf("Tråd %3ld -> %d\n", (long) nr, terning);
            pthread_mutex_unlock(&mutex);
        }
        
		usleep(rand() % MAX_WAIT + 1);
	}
}

void main()
{
	int n;
	long i;
	pthread_t t;

	printf("n? ");
	scanf("%d", &n);

	pthread_mutex_init(&mutex, NULL);
    // Initierer betinget blokkering
    pthread_cond_init(&cond, NULL);
	
	for (i = 0; i < n; i++)
	    pthread_create(&t, NULL, terningkast, (void *) i);

	pthread_join(t, NULL);
}