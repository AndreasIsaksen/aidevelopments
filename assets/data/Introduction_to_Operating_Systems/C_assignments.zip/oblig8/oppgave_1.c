#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Struktur som lagrer data om en prosess
struct process
{
	int id;		// Prosess-ID
	int arrive; // Tidspunkt da prosessen ble satt inn i kø 
	int cpu;	// Total CPU-tid som prosessen krever
	int start;	// Tidspunkt da prosessen startet å kjøre
	int end;	// Tidspunkt da prosessen er ferdig
};

// Globale variabler
int T = 0;			// Systemtid, starter simulering ved tid lik 0
int N;			    // Antall prosesser
struct process *P;  // Peker til array med prosessene

// read_file(): Leser data for N prosesser fra fil. Prosessene skal
// ligge sortert på ankomsttid. Alle data må være ikke-negative
// heltall. Alle tider oppgis i hele tidsenheter. Filformat:
//
//	 N
//	 id arrive CPU
//	 id arrive CPU
//	 id arrive CPU
//	 ...
//
void read_file(char *filename)
{
	int i, last_arrive = 0;
	FILE *p_file;
	
	// Åpner fil og sjekker for feil i åpning
	p_file = fopen(filename, "r");
	if (p_file == NULL)
	{
		printf("Feil ved åpning av filen \"%s\"\n", filename); 
		exit(-1);
	}

	// Leser antall prosesser
	fscanf(p_file, "%d", &N);

	// Oppretter array med plass til alle prosessene
	P = (struct process *) malloc(N * sizeof(struct process));

	// Leser inn en og en prosess. Prosessene skal ligge sortert på
	// ankomsttid i filen, hvis ikke gis en feilmelding.
	for (i = 0; i < N; i++)
	{
		fscanf(p_file, "%d %d %d", &P[i].id, &P[i].arrive, &P[i].cpu);
		P[i].start = P[i].end = 0;
		
		if (P[i].arrive < last_arrive)
		{
            printf("Feil i ankomsttider, prosess %d\n", P[i].id);
			exit(-1);
		}
		last_arrive = P[i].arrive;
	}
	fclose(p_file);
}

// simulate(): Simulering av batch scheduling. "Kjører" til alle
// prosessene er ferdige.
//
void simulate()
{
    int i;                                  // Deklarerer variabel for iterering
    float wait = 0, turnaround = 0;         // Variabler for ventetid og turnaround
    printf("P\tArrive\tCPU\tStart\tEnd\n"); // Overskrift på print

    // For loop som tar for seg array P basert på N prosesser
    for(i=0; i<N; i++) {

        // Om arrive er mindre eller lik T vil arrive bli startpunkt for prosess
        if(T >= P[i].arrive) {
            P[i].start = T;
        } else {
            P[i].start = P[i].arrive;
        }
        
        P[i].end = P[i].start + P[i].cpu;       // Regner ut end for hver prosess
        turnaround += P[i].end - P[i].arrive;   // Regner turnaround for hver prosess
        wait += P[i].start - P[i].arrive;       // Regner ventetid for hver prosess
        T = P[i].end;                           // Gir T en ny verdi for hver prosess end
        
        // Print for hver prosess
        printf("%d\t%d\t%d\t%d\t%d\n",
        P[i].id, P[i].arrive, P[i].cpu, P[i].start, P[i].end);
    }
    
    // Avrunder turnaround og ventetid.
    turnaround = turnaround/N;
    wait = wait/N;
    printf("\nAverage turnaround:\t%.2f\n", turnaround);
    printf("Average wait-time :\t%.2f\n", wait);
}


// main(): Leser filnavn med prosessdata, leser fil og kjører scheduling
//
int main()
{
	char filename[100];

	// Leser filnavn fra bruker
	printf("File? ");
	scanf("%s", filename);

	// Leser inn prosessdataene
	read_file(filename);

	// Simulerer batch-scheduling
	simulate();
}