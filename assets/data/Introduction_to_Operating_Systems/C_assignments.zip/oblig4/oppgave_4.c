#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <string.h>

int main() {
	//Her starter en barneprosess via fork()
    pid_t child = fork();

    if (child < 0) {
        // Sjekk på om fork() feilet.
        // Returnerer status 1 ved feiling.
        perror("Fork failed");
        return 1;
    }

    // If sjekk på om det er en forelder- eller barneprosess
    if (child == 0) {
        
        // Danner en array list som holder på utrykket vi skal bruke i
        //barneprosessen.
        char *argv[3];
        argv[0] = strdup("ping");
        argv[1] = strdup("www.vg.no");
        argv[2] = NULL;
        
        // Her bytter barneprosessen seg ut med en annen prosess som kjører ping
        // kommandoen fra arraylisten.
        execvp(argv[0], argv);
        return 0;
    } else {
        // Her startet foreldreprosessen en fem sekunders pause før den går videre.
        printf("Forelder (PID %d) tar seg 5 mens barna (PID %d) leker.\n", getpid(), child);
        sleep(5);

        // Her terminerer foreldreprosessen barnet.
        // Jeg har valgt å bruke SIGNTERM, da dette er den defualt signalet til kill() kommandoen
        // Dette gjør at barneprosessen får muligheten til å avslutte alt på rikitg måte,
        // og gi fra seg opptatt minnet før det terminerer.
        // SIGNINT er tilsvarende "Ctrl+c" i terminalen på en foreliggende prosess. Her
        // will du gjøre en "Soft interruption" som tvinger en terminering, men gir prosessen
        // mulighet til å avlutte på vanlig måte.
        // SIGNKILL er tilsvarende "kill(9)". Dette er en tvungen handling som vil stoppe
        // prosessen uavhengig av hvor den er i løpet. Denne brukes på prosesser som sitter
        // fast i en handling(f.eks. evig loop) eller er uresponsiv.
        printf("Forelder (PID %d) bråvåkner og tar livet av barnet (PID %d) sitt...\n", getpid(), child);
        if (kill(child, SIGTERM) == 0) {
            printf("Alt er stille nå. Barnet (PID %d) er ikke lenger med oss...\n", child);
        } else {
            perror("Mørket faller og barnet (PID %d) lever enda. Gjem deg godt å håp det ikke finner deg!\n");
        }

        // Her venter foreldreprosessen på at barnet skal terminere før det avslutter selv.
        wait(NULL);
    }

    return 0;
}
