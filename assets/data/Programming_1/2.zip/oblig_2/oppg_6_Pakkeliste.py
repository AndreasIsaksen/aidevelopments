#En liten intoduksjon som printes til bruker når programmet starer
print("Heisann reisevenn!")
print("Hva ønsker du å gjøre i dag?")

#Lager en liste variabel som brukes til å lagre brukers elementer
pakkeliste = []

#Disse variabelene måtte jeg lage for at while loopene i programmet skulle starte opp.
options = ''
deloptions = ''

#Her starter selve programmet som bruker kommer til å sitte i.
#Hele programmet er nestet i en while loop, med flere loop løsninger og if/else sjekker basert på brukers input.
#Bruker får to muligheter til å velge et alternativ i programmet(kommando eller tall alternativer)
#For å avslutte programmet må bruker skrive quit når de er i hovedmenyen.
while options != 'quit':
    options = input("\n1.Legge til i listen(skriv 1 eller add)\n2.Slette noe fra listen(skriv 2 eller delete)\n3.Se hva som ligger i listen(skriv 3 eller liste)\nSkriv 'quit' for å avslutte programmet\n")
    
#Dette er løsningen for å legge til elemnter i listen.
    if options == '1' or options == 'add':
#Her spør vi hvor mange elemter bruker vil legge til
        additions = int(input("Hvor mange ting vil du legge til?\n"))
#Her legger bruker til elementer i listen basert på det predefinerte antallet som skal legges til
        while additions >= 1:
            pakkeliste.append(input("Legge til i pakkeliste:\n"))
            additions -= 1
#Etter at elementer er lagt til printes ut en oversikt på listens innhold
        print("Din liste inneholder nå:")
        for innhold in pakkeliste:
            print(innhold)
#Dette er løsningen for å fjerne elementer i listen
    elif options == '2' or options == 'delete':
#Først kjøres en sjekk på om listen har innhold. Om ikke går det tilbake til hovedmeny
        if not pakkeliste:
            print("Listen er tom!")
            continue
#Om listen har innhold blir listeinnholdt printet, og bruker kan definere hva som skal fjernes
        else:
            print("Listen inneholder nå:")
        for innhold in pakkeliste:
            print(innhold)
        print("Skriv inn hvilket element ønsker du å slette(skriv ferdig når du ikke vil slette mer).\n")
#Fjerning av elementer går i en while loop frem til bruker skriver 'ferdig' eller listen er tom.
#String verdien i condition på while loop under står slik, da jeg ikke fikk den til å fungere uten.
#Så lenge 'noesomjeghåperikkeblirskrevet' ikke blir skrevet når man skal fjerne et element fungerer alt som det skal
#Om man skriver 'noesomjeghåperikkeblirskrevet' under fjerning av elementer,
#er det ikke sikkert at man kommer inn på fjerning igjen fra hovedmenyen.
        while deloptions != 'noesomjeghåperikkeblirskrevet':
            if not pakkeliste:
                print("Listen er tom!")
                break
            deloptions = input("Hva vil du fjerne?(skriv ferdig når du er ferdig)\n")
            if deloptions == 'ferdig':
                break
            elif deloptions not in pakkeliste:
                print(f"Kunne ikke finne {deloptions} i listen. Har du skrevet riktig?")
                continue
            else:    
                pakkeliste.remove(deloptions)
                print(f"{deloptions} er nå fjernet fra listen.")
#Her er løsningen for å printe listen.
#Om listen er tom får man en beskjed kontra om listen har innhold.
    elif options == '3' or options == 'liste':
        if not pakkeliste:
            print("Ingenting er lagt i listen enda.")
        else:
            print("Her er hva du har i listen for øyeblikket:")
            for innhold in pakkeliste:
                print(innhold)
        print("\n")            
#Om det blir skrevet noe som ikke passer med alternativene, får man en feilmelding og hovedmeny starter på nytt.
    else:
        if options != 'quit':
            print(f"\n{options} er ikke et gyldig alternativ.")
            continue
        else:
            continue
        

