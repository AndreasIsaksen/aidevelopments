#Her lager vi listen fra oppg 3.
tolkien = ['The Hobbit', 'Farmer Giles of Ham', 'The Fellowship of the Ring', 'The Two Towers', 'The Return of the King', 'The Adventures of Tom Bombadil', 'Tree and Leaf']

#Her redefinerer vi string elementene vi vil ha ut til å inneholde 'Lord of the Rings'
tolkien[2] = 'Lord of the Rings I: The Fellowship of the Ring'
tolkien[3] = 'Lord of the Rings II: The Two Towers'
tolkien[4] = 'Lord of the Rings III: The Return of the King'

#Her lager vi en ny liste som looper gjennom den første listen og henter ut alle datasett som har 'Lord of the Rings' i string verdien.
LOTR = [triology for triology in tolkien if 'Lord of the Rings' in triology]

#Her printes den ut som en hel liste
print(LOTR)

#Her brukes en for each loop til å iterere gjennom den nye listen og printe ut et datasett av gangen.
for book in LOTR:
    print(book)

#Kilder:
#Medelever på Discord
#Python Crash course (3'rd edition)