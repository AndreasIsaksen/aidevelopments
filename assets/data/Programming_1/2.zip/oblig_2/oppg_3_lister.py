tolkien = ['The Hobbit', 'Farmer Giles of Ham', 'The Fellowship of the Ring', 'The Two Towers', 'The Return of the King', 'The Adventures of Tom Bombadil', 'Tree and Leaf']

#Skriv ut de to første og de to siste bøkene i listen.
print(f"{tolkien[0]}\n{tolkien[1]}\n{tolkien[-1]}\n{tolkien[-2]}")

#Legg til to av bøkene som ble utgitt etter hans død
tolkien.append('The Silmarillion')
tolkien.append('Unfinished Tales')

#Gjør endringer på de tre bøkene i Lord of the Rings trilogien og legg til "Lord of the Rings: " foran hver av dem
tolkien[2] = 'Lord of the Rings I: The Fellowship of the Ring'
tolkien[3] = 'Lord of the Rings II: The Two Towers'
tolkien[4] = 'Lord of the Rings III: The Return of the King'

#Sorter lista og skriv den ut. 
tolkien.sort()
print(tolkien)

#Kilder:
#Medelever på Discord
#Python Crash course (3'rd edition)