#Definerer variabelen oddefor
#I oddefor blir det laget en liste med variabelen odde hvor for løkke blir brukt til å lage int elementer fra 9 til 101 i 2 gangen
oddefor = [odde for odde in range(9, 101, 2)]
#Her brukes "for else" løkke til å hente ut hvert element i listen til oddefor og printe dette ett element av gangen gjennom variabelen nitilhunderogen
for nitilhunderogen in oddefor:
    print(nitilhunderogen)

#Definerer variabelen oddetall til 9
oddetall = 9
#Lager en while løkke som itererer så lenge variabelen oddetall er mindre enn 101
while oddetall < 101:
#Printer hvert tall etter som while løkken kjører
    print(oddetall)
#Legger på 2 i verdi for hver gang løkken itereres
    oddetall += 2

#Kilder:
#Medelever på Discord
#Python Crash course (3'rd edition)