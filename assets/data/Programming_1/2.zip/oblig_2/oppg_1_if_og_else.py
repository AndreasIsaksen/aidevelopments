#Først definerer jeg det korrekte svaret i variabelen correct
correct = 42
#Så setter jeg variabelen inn i en while løkke, slik at spørsmålet kan repeteres
while correct:
#Deretter lager jeg en input spøøring til bruker hvor input blir definert som et integer dataset
#Dette krever at bruker skriver et tall, eller blir resultatet "ValueError" og while løkken avsluttes.
    answer = int(input("Hva er svaret på det ultimate spørsmålet om livet, universet og alle ting? Hint: Det er et tall.\n"))
#Om bruker skriver 42 slår if statementen ut og bruker får riktig svar, og programmet avsluttes.
    if answer == 42:
        print("Det stemmer, meningen med livet er 42!")
        exit()
#Om bruker skriver et tall over 30 og under 50 får de beskjed om at de er nærme, men ikke i mål og blir spurt på nytt.
    elif answer > 30 and answer < 50:
        print("Nærme,men feil.")
#Om bruker skriver et tall under 30 eller over 50 får de beskjed om at dette er feil, og blir spurt på nytt.
    else:
        print("FEIL!")

#Kilder:
#Medelever på Discord
#Python Crash course (3'rd edition)