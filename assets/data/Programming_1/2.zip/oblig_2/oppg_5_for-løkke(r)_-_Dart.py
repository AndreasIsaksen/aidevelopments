#Importerer random funksjonen
import random

#Lager en tom liste som skal holde på spiller navn
nameList = []

#Lager variabel som skal brukes til å definere når while loopen for navnskriving skal avsluttes
namePlace = 1

#En variabel hvor bruker skriver antall deltagere
players = int(input("Hvor mange spillere er dere?\n"))

#while loop legger til navn fra bruker frem til antall spillere matcher namePlace variabelen
while namePlace <= players:
    nameList.append(str(input(f"Skriv inn {namePlace}. spillers navn\n")))
    namePlace += 1

#Variabel som brukes for å vise antall kast i for each loopen under
throw = 1

#En tom liste som holder på de samlede poengene fra for each loopen under
pointList = []

#Denne for each loopen genererer pong for tre kast, summerer poengene og printer poengene for hver deltager.
#Når 3 piler er kastet blir antallet kast satt tilbake til 1 for neste deltagers runde
for name in nameList:
    points = [random.randrange(0, 60), random.randrange(0, 60), random.randrange(0, 60)]
    score = points[0]+points[1]+points[2]
    pointList.append(score)
    for kast in points:
        print(f"{name} fikk {kast} poeng på {throw}. kast")
        throw += 1
        if throw >= 4:
            throw = 1

#For each loop med zip funksjon som lister opp samlede poeng for spillerne etter hverandre.
for name, summary in zip(nameList, pointList):
    print(f"{name} fikk totalt: {summary} poeng!")


#Kilder:
#https://www.w3schools.com/python/ref_func_zip.asp
#https://www.w3schools.com/python/ref_random_randrange.asp
#https://docs.python.org/3/reference/import.html
#https://docs.python.org/3/tutorial/controlflow.html
#https://www.geeksforgeeks.org/python-while-loop/
#https://stackoverflow.com/questions/3752618/python-adding-element-to-list-while-iterating
#https://www.w3schools.com/python/python_while_loops.asp
#https://www.w3schools.com/python/ref_string_title.asp
#Medelever på Discord
#Python Crash course (3'rd edition)