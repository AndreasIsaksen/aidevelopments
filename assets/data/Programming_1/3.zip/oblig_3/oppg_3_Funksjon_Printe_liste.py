#Først lager jeg funksjonen print_list
def print_list(liste):
    #Så lager jeg en for-løkke som printer ut alle elementene i listen
    for element in liste:
        print(element)
    return

#Så lager jeg en liste med mine tre favorittretter
favorittretter = ["Pizza", "Kebab", "Taco"]

#Så kaller jeg funksjonen print_list og sender med listen med mine favorittretter
print_list(favorittretter)