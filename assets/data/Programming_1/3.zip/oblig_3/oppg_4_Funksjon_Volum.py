#Først definerer jeg en variabel som skal brukes til å sjekke om while loop skal fortsette eller ikke
choise = ""

#Så lager jeg en while loop som kjører så lenge choise ikke er 'n'
while choise != "n":
    def volum(l,b,h):
        return (h*l*b) / 1000000

#Deretter spør jeg bruker om lengder i centimeter
    print("Skriv lengder i centimeter")
    l = int (input("Lengde\n"))
    b = int (input("Bredde\n"))
    h = int (input("Høyde\n"))

#Her kalles funksjonens verider og konverterer til kubikkmeter før den printer ut resultatet
    print (f"Volumet av objektet er {volum(l,b,h)} kubikkmeter")
    print(f"Ønsker du å fortsette? (y/n): ")
    choise = input()
    continue

#Her er eksempler på kjøring av programmet
print(f"{volum(10,10,10)} kubikkmeter")
print(f"{volum(25,25,25)} kubikkmeter")
print(f"{volum(50,50,50)} kubikkmeter")
print(f"{volum(100,100,100)} kubikkmeter")
print(f"{volum(15,76,45)} kubikkmeter")