#Først importerer jeg random modulen
import random

#Så definerer jeg en funksjon som genererer et tilfeldig tall mellom 0 og 100
def tilfeldig_tall():
    return random.randrange(0,100)

#Her kaller jeg funksjonen og printer ut resultatet
print(f"*********\n***{tilfeldig_tall()}****\n*********")