#Starter med å lage en variabel som skal brukes i while loopen
slutt = ""

#Så lager jeg en tom liste som skal holde på filmene
movielist = []

#Her lager jeg et separert dictionary for filmene fra oppgaven
movie_1 = {
    "name": "Inception",
    "year": 2010,
    "rating": 8.7
}

movie_2 = {
    "name": "Inside Out",
    "year": 2015,
    "rating": 8.1
}

movie_3 = {
    "name": "Con Air",
    "year": 1997,
    "rating": 6.7
}

#Her legger jeg til dictionary i listen
movielist.append(movie_1)
movielist.append(movie_2)
movielist.append(movie_3)


#A)
#Denne funksjonen definerer en variabel for hver key i dictionay,
#som brukes i for loopen til å kjøre ut listen i ønsket format
def fixFormat():
    for movies in movielist:
        name = movies["name"]
        year = movies["year"]
        score = movies["rating"]
        print(f"{name} - {year} has a rating of {score}.")


#Her kaller jeg på funksjonen til A)
fixFormat()

#B)
#Her lager jeg en funksjon som regner snitt på ratings av filmer
def scoreSnitt():
#Først må jeg lage en variabel med en 0 verdi som funksjonen bruker til å starte utregning
    ratingStart = 0
#Så trenger jeg en variabel som teller antallet elementer i listen
    listElements = len(movielist)
#Så lages en for loop som summerer verdiene
    for ratings in movielist:
        ratingStart += ratings["rating"]
#Deretter tar jeg summen og deler på antallet filmer
    rateSnitt = ratingStart / listElements
#Så printer jeg ut gjennomsnittet
    print(f"Snitt rating på de {len(movielist)} filemene i listen er {rateSnitt}.")


#Her kaller jeg på funksjonen til B)
scoreSnitt()

#C)
#Her lager jeg en funksjon som tar en liste med filmer og et årstall som parametere, og returnerer en ny liste med alle filmer fra og med det gitte årstallet.
def yearList(year):
#Først lager jeg en tom liste som skal holde på filmene
    yearList = []
#Så lager jeg en for loop som sjekker om filmene i listen er fra og med det gitte årstallet
    for movies in movielist:
        if movies["year"] >= year:
            yearList.append(movies)
#Til slutt for looper funksjonen gjennom den nye listen og gir tilsvarende setning som tidligere,
#men ut i fra det definerte årstallet i funksjonens parameter
    for movies in yearList:
        print(f"{movies['name']} - {movies['year']} has a rating of {movies['rating']}.")


#Her kaller jeg på fuksjonen til C)
yearList(2010)