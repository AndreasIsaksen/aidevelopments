#A)
#Starter med å lage en variabel som skal brukes i while loopen
slutt = ""

#Så lager jeg en tom liste som skal holde på filmene
movielist = []

#Her lager jeg et separert dictionary for filmene fra oppgaven
inception = {
    "name": "Inception",
    "year": 2010,
    "rating": 8.7
}

inside_out = {
    "name": "Inside Out",
    "year": 2015,
    "rating": 8.1
}

con_air = {
    "name": "Con Air",
    "year": 1997,
    "rating": 6.7
}

#Her legger jeg til dictionary i listen
movielist.append(inception)
movielist.append(inside_out)
movielist.append(con_air)

#B)
#Her lager jeg en funksjon som legger til flere filmer i listen
def addmovie():
    movie = {}
    movie["name"] = input("Hva heter filmen?\n")
    movie["year"] = int(input("Når kom den ut?\n"))
    movie["rating"] = (input("Hvilken skår fikk den?\n"))
#C)
#Denne if statementen setter rating til 5.0 om bruker ikke skriver noe
    if movie["rating"] == "":
        movie["rating"] = 5.0
#Siste del av funksjonen legger til input som en ny dictionary i listen
    movielist.append(movie)
    return

#Her kaller jeg på funksjonen addmovie() og spør om bruker vil legge til flere filmer
while slutt != "n":
    print("Ønsker du å legge til en film før listen prites?(y/n)")
    slutt = input()
    if slutt == "n":
        break
    addmovie()
    print("Ønsker du å legge til en film til?(y/n)\n")
    slutt = input()
    continue

#Her kjøres ut verdiene til de dictionary som ligger i listen etter at bruker er ferdig
for filmer in movielist:
    for value in filmer.values():
        print(value)

#Her printes listen ut i sin helhet
print(movielist)