#Her starter jeg med å opprette et dictonary
student = {
    "fornavn": "Ola",
    "etternavn": "Nordmann",
    "favorittfag": "Programmering 1"
}

#Her printer jeg ut studentens fullstendige navn
print(f"{student['fornavn']} {student['etternavn']}")

#Her endrer jeg favorittfaget til studenten
student["favorittfag"] = "ITF10219 Programmering 1"

#Her printer jeg ut studentens favorittfag
print(student["favorittfag"])

#Her legger jeg til alder på studenten
student["alder"] = 20

#Her printer jeg ut studentens fulle navn, alder og favorittfag
print(f"{student['fornavn']} {student['etternavn']} er {student['alder']} år gammel og liker {student['favorittfag']}")