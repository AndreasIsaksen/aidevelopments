#Lager lister som skal holde på verdier
movielist = []
lineList = []

#Lager et separert dictionary for filmene fra oppgaven
movie_1 = {
    "name": "Inception",
    "year": 2010,
    "rating": 8.7
}

movie_2 = {
    "name": "Inside Out",
    "year": 2015,
    "rating": 8.1
}

movie_3 = {
    "name": "Con Air",
    "year": 1997,
    "rating": 6.7
}

#Legger til dictionary i listen
movielist.append(movie_1)
movielist.append(movie_2)
movielist.append(movie_3)


#Funksjon som lar brukeren velge om de vil legge til filmer i listen
def choice():
    slutt = ""
    while slutt != "n":
        slutt = input("Ønsker du å legge til en film i listen?(y/n):")
        if slutt == "n":
            continue
        else:
            addmovie()


#Funksjon for å legge til filmer i listen
def addmovie(): 
    movie = {}
    movie["name"] = input("Hva heter filmen?\n")
    movie["year"] = int(input("Når kom den ut?\n"))
    movie["rating"] = (input("Hvilken skår fikk den?\n"))
    if movie["rating"] == "":
        movie["rating"] = 5.0
    movielist.append(movie)
    return



#Funksjon som setter filmene i en setning
def fixFormat():
    for movies in movielist:
        name = movies["name"]
        year = movies["year"]
        score = movies["rating"]
        lineList.append(f"{name} - {year} has a rating of {score}.\n")
    return lineList


#Funksjon som skriver strings til filen movies.txt i text_file mappen
def list2string():
    with open("oppg_5,3_text_file/movies.txt", "w") as file:
        for line in lineList:
            file.write(line)

#B)
#Funksjon som printer innholdet i filen movies.txt linje for linje i terminalen
def readBack(file_location):
    file = open(file_location, "r")
    print("Dette er filmene som er lagt til i listen:\n")
    for x in file:
        print(x)
    file.close()


#A)
#Her kaller jeg på funksjonene som gjør at bruker får mulighet til å legge til
#nye filer i listen, før den blir skrevet til filen movies.txt
choice()
fixFormat()
list2string()
#B)
#Her kaller jeg på funksjonen som leser filen movies.txt
readBack("oppg_5,3_text_file/movies.txt")