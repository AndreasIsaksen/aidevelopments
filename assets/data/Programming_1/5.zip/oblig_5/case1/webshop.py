#------------------------------------------
#Oppgaver              Case 1 - Oppgave 1-7
#------------------------------------------

# Oppgave 1
def print_ware_information(ware):
    print(f"\nName: {ware['name']}")
    print(f"Price: {ware['price']}")
    print(f"Number in stock: {ware['number_in_stock']}")
    print(f"Desscription: {ware['description']}\n")


# Oppgave 2
def calculate_average_ware_rating(ware):
    average = 0
    for rating in ware['ratings']:
        average += rating
    average = average / len(ware['ratings'])
    average = round(average, 1)
    return average


# Oppgave 3
def get_all_wares_in_stock(all_wares):
    print("Wares currently in stock:")
    wares_in_stock = {}
    for key, ware in all_wares.items():
        if is_ware_in_stock(ware):
            wares_in_stock[key] = ware
    return wares_in_stock


# Oppgave 4
def is_number_of_ware_in_stock(ware, number_of_ware):
    return ware["number_in_stock"] >= number_of_ware


# Oppgave 5
def add_number_of_ware_to_shopping_cart(ware_key, ware, shopping_cart, number_of_ware):
    available_stock = ware["number_in_stock"]

    if available_stock == 0:
        print(f"Not enough {ware['name']} in stock. Unable to add to the shopping cart.")

    elif number_of_ware > available_stock:
        added_quantity = available_stock
        
        if ware_key not in shopping_cart:
            shopping_cart[ware_key] = added_quantity
            ware["number_in_stock"] -= added_quantity
        else:
            shopping_cart[ware_key] += added_quantity
            ware["number_in_stock"] -= added_quantity
        
        print(f"We only have {available_stock} {ware['name']} in stock.")
        print(f"Added {available_stock} {ware['name']} to the shopping cart.")

    elif available_stock > 0:
        added_quantity = min(available_stock, number_of_ware)

        if ware_key not in shopping_cart:
            shopping_cart[ware_key] = added_quantity
            ware["number_in_stock"] -= added_quantity
        else:
            shopping_cart[ware_key] += added_quantity
            ware["number_in_stock"] -= added_quantity

        print(f"Added {added_quantity} {ware['name']} to the shopping cart.")
        print(f"Current quantity of {ware['name']} in the shopping cart: {shopping_cart[ware_key]}")


# Oppgave 6
def calculate_shopping_cart_price(shopping_cart, all_wares, tax):
    total_price = 0
    for ware_key, quantity in shopping_cart.items():
        total_price += all_wares[ware_key]["price"] * quantity
    total_price = total_price * (1 + tax)
    return total_price


# Oppgave 7
def can_afford_shopping_cart(shopping_cart_price, wallet):
    return wallet >= shopping_cart_price


def buy_shopping_cart():
    '''Kjøper varene i en handlevogn. Parameterene defineres i oppgaven.'''

#------------------------------------------
# Predefinerte funksjoner
#------------------------------------------

def is_ware_in_stock(ware):
    if ware["number_in_stock"] >= 1:
        return True
    else:
        return False


def clear_shopping_cart(shopping_cart):
    '''Tømmer en handlevogn.'''
    shopping_cart.clear()