import webshop as ws
from wallet import Wallet

all_wares = {
    "amd_processor": {
        "name": "AMD Ryzen 9 5900X Processor",
        "price": 5590.0,
        "number_in_stock": 50,
        "ratings": [4.5, 4.0, 5.0, 5.0, 4.5, 3.0],
        "description": "All the cores and threads you'll need!",
    },

    "playstation_5": {
        "name": "PlayStation 5",
        "price": 5999.0,
        "number_in_stock": 0,
        "ratings": [5.0, 5.0, 4.5, 2.0, 5.0, 4.5, 4.0],
        "description": "Next generation console, never in stock!",
    },

    "hdmi_cable": {
        "name": "Belkin Ultra High Speed HDMI Cable - 2m",
        "price": 349.0,
        "number_in_stock": 3,
        "ratings": [5.0, 5.0, 4.5, 5.0, 5.0, 5.0],
        "description": "A high speed overprices HDMI cable!",
    }
}

#Case 1 - Funksjon som printer ut info om et produkt
print("\nProduct information:")
ws.print_ware_information(all_wares["amd_processor"])

#Filtrer ut alle varer som er på lager og skriv ut informasjonen for hver av dem
all_wares_in_stock = ws.get_all_wares_in_stock(all_wares)
for ware in all_wares_in_stock.values():
    ws.print_ware_information(ware)

# Skriv ut den gjennomsnittlige ratingen for denne varen
print("Average rating for our products:")
print(f"Average rating for the AMD Processor: {ws.calculate_average_ware_rating(all_wares['amd_processor'])}")
print(f"Average rating for the Playstation 5: {ws.calculate_average_ware_rating(all_wares['playstation_5'])}")
print(f"Average rating for the HDMI cable: {ws.calculate_average_ware_rating(all_wares['hdmi_cable'])}")
print()

# Skriv ut om det er nok varer på lager
print("Storage status on our products:")
beholdning = int(input("Please enter the quantity you're looking for:\n"))
for ware_key, ware in all_wares.items():
    if ws.is_number_of_ware_in_stock(ware, beholdning):
        print(f"There are at least {beholdning} {ware_key} in stock")
    else:
        print(f"There are not enough {ware_key} in stock")

# Oppretter en tom handlevogn
shopping_cart = {}
print()
# Forsøker å legge til 1 amd processor, 2 playstation 5 konsoller og 10 hdmi kabler
ws.add_number_of_ware_to_shopping_cart("amd_processor", all_wares["amd_processor"], shopping_cart, 2)
ws.add_number_of_ware_to_shopping_cart ("playstation_5", all_wares["playstation_5"], shopping_cart, 2)
ws.add_number_of_ware_to_shopping_cart ("hdmi_cable", all_wares["hdmi_cable"], shopping_cart, 10)

# skriver ut handlevognen
print()
print(f"The shopping cart:")
for product, quantity in shopping_cart.items():
    print(f"{product}: {quantity}")
print(f"Which comes to a total price of: {ws.calculate_shopping_cart_price(shopping_cart, all_wares, 0.25)} NOK with taxes")
print()

# Oppretter en lommebok som inneholder 10000 kr
wallet = Wallet(10000)

# Forsøker å kjøpe varene i handlevognen
#ws.buy_shopping_cart('''Parameterne blir definert i oppgaven''')
#print()

# Skriver ut mengden penger i lommeboka etter kjøpet
print(f"The amount in the wallet after the purchase: {wallet.get_amount()}")

if ws.can_afford_shopping_cart(ws.calculate_shopping_cart_price(shopping_cart, all_wares, 0.25), wallet.get_amount()):
    print(f"You can afford the shopping cart with {wallet.get_amount() - ws.calculate_shopping_cart_price(shopping_cart, all_wares, 0.25)} NOK to spare.")
else:
    print(f"You're missing {ws.calculate_shopping_cart_price(shopping_cart, all_wares, 0.25) - wallet.get_amount()} NOK to afford the shopping cart.")