#Først definerer jeg variablene
a = 6
b = 3
c = 2
#Så printer jeg ut oppgavene med en oppgave index foran løsningen.
print("a)",a+b*c)
print("b)",(a+b)*c)
print("c)",a/b/c)
print("d)",a/(b/c))
