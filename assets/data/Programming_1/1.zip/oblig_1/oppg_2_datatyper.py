#Først definerer jeg de forskjellige verdier i variabler med passende relasjon.
name = "Andreas"
surname = "Isaksen"
age = "33"
#Så fester jeg disse variablene til en setning, som blir en kort introduksjon av meg selv.
print(f"Hei. Jeg heter {name} {surname} og er {age} år gammel.")