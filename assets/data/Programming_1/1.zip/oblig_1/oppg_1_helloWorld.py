#Her definerer jeg en variabel til å holde verdien "Hello world!"
message = "Hello world!"
#Her printer jeg ut denne verdien gjennom den definerte variabel
print(message)