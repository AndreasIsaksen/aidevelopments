#Først lager jeg en tom liste over kakespisere
kakespisere = []
#Så legger jeg til antallet kaker spist fra de forskjellige kakespiserne
kakespisere.append(5)
kakespisere.append(9)
kakespisere.append(2.5)
kakespisere.append(21)
kakespisere.append(0)
#Deretter summerer jeg antall kaker spist fra listen
kaker = sum(kakespisere)
#For så å summere antall kakespisere fra listen
spisere = len(kakespisere)
#Til slutt printer jeg ut resultatet ved å dele antall kaker på antall spisere.
print(kaker/spisere)
print(f"(eller {kaker//spisere} om du runder ned)")