#Her har jeg tre linjer hvor bruker blir bedt om å legge inn to tall verdier og en operator 
num1 = float(input("Ditt første tall\n"))
num2 = float(input("Ditt andre tall\n"))
ops = input("Plusse(+), trekke(-), gange(*) eller dele(/)?\n")

#Her utføres regnestykket ut i fra hvilken operator bruker har valgt(Om det ikke er valgt noen operator, får bruker feilmelding)
if ops == '+':
    print(f"Svaret ditt er: {num1+num2}")
elif ops == '-':
    print(f"Svaret ditt er: {num1-num2}")
elif ops == '*':
    print(f"Svaret ditt er: {num1*num2}")
elif ops == '/':
    print(f"Svaret ditt er: {num1/num2}")
else:
    print("Du er nødt til å velge en av de fire operatorene. Prøv igjen")