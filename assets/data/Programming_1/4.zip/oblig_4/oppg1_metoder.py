from oppg1_movies import Movies


inception = Movies("Inception", 2010, 8.8)
the_martian = Movies("The Martian", 2015, 8.0)
joker = Movies("Joker", 2019, 8.4)

print(inception.line())
print(the_martian.line())
print(joker.line())