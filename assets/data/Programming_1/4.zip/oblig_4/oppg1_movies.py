
#A
class Movies:
    def __init__(self, title, year, rating):
        self.title = title
        self.year = year
        self.rating = rating

#B
    def line(self):
        return f"{self.title} was released in {self.year} and currently has a score of {self.rating}\n"

#A
inception = Movies("Inception", 2010, 8.8)
the_martian = Movies("The Martian", 2015, 8.0)
joker = Movies("Joker", 2019, 8.4)

print(f"{inception.title} was released in {inception.year} and currently has a score of {inception.rating}\n")
print(f"{the_martian.title} was released in {the_martian.year} and currently has a score of {the_martian.rating}\n")
print(f"{joker.title} was released in {joker.year} and currently has a score of {joker.rating}\n")

#B
print(inception.line())
print(the_martian.line())
print(joker.line())