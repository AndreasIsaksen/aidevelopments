#**************************METHOD IMPORT**********************************
import random

#**************************CARDS**********************************

# Create a list of cards
genres = ["Hearts", "Diamonds", "Spades", "Clubs"]
values = ["Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"]

# Define a deck
deck = [{"genre": genre, "value": value} for genre in genres for value in values]

# Function to shuffle deck
def shuffle_deck():
    random.shuffle(deck)


#**************************PLAYER REGISTER**********************************

try:    
    # Define a player
    def register(name, age):
            x = {
            "name": name,
            "age": age,
            "chips": 100
            }
            return x

    #**************************GAME FUNCTIONS**********************************

    # Function to define value of hand
    def hand_value(hand):
        value = 0
        ace_value = 0

        for card in hand:
            if card["value"] == "Ace":
                value += 11
                ace_value += 1
            elif card["value"] in ["Jack", "Queen", "King"]:
                value += 10
            else:
                value += int(card["value"])

        while value > 21 and ace_value > 0:
            value -= 10
            ace_value -= 1

        return value


    # Function to control player balance
    def check_balance():
        if player["chips"] <= 0:
            print("Seems like your out of chips.\nBetter luck next time.")
            exit()
        else:
            pass



    # Current bet placeholder
    current_bet = 0
    # Function to place bet
    def player_bet():
        while True:
            print(f"\nYou currently have {player['chips']} chips")
            bet = int(input("How much do you want to bet?\n"))
            if bet > player["chips"]:
                print("You don't have enough chips.\nPlease try a smaler bet.")
            else:
                player["chips"] -= bet
                global current_bet
                current_bet += bet
                print(f"\nYou've bet {bet} chips")
                return False


    # Function to display a player's hand
    def display_hand(hand):
        print("\nYour hand is:")
        for card in hand:
            print(f'{card["value"]} of {card["genre"]}')
        print(f"Wich gives a total value of: {hand_value(hand)}")


    # Function to show dealers first card
    def display_dealer_hand(hand):
        print("\nThe dealer has:")
        print(f'{hand[0]["value"]} of {hand[0]["genre"]}')
        print("And one card facing down")


    # Function for dealers turn
    def dealer_turn(hand):
        global current_bet, pscore, dealer_hand
        print("\nThe dealer has:")
        for card in hand:
            print(f'{card["value"]} of {card["genre"]}')
        print(f"Wich gives a total value of: {hand_value(hand)}")

        while True:
            if hand_value(hand) < pscore and hand_value(hand) < 21:
                print("Dealer picks a card.")
                pick_card(hand)
                print(f"Dealer gets a {dealer_hand[-1]['value']} of {dealer_hand[-1]['genre']}")
                print(f"Wich gives dealer a total value of: {hand_value(hand)}")
                if hand_value(hand) > 21:
                    print(f"Dealer busted. You win {current_bet * 2} chips!\n")
                    player["chips"] += current_bet * 2
                    print(f"Your current balance is {player['chips']} chips.\n")
                    current_bet = 0
                    dealer_hand = []
                    call_or_quit()

                elif hand_value(hand) > pscore and hand_value(hand) <= 21:
                    print("Dealer wins.")
                    print(f"You lost {current_bet} chips this round")
                    current_bet = 0
                    dealer_hand = []
                    call_or_quit()

                elif hand_value(hand) == pscore:
                    print("It's a draw and chips are returned.")
                    player["chips"] += current_bet
                    current_bet = 0
                    dealer_hand = []
                    call_or_quit()

            elif hand_value(hand) > pscore:
                    print("Dealer wins.")
                    print(f"You lost {current_bet} chips this round")
                    current_bet = 0
                    dealer_hand = []
                    call_or_quit()

            elif hand_value(hand) == pscore:
                print("It's a draw and chips are returned.")
                player["chips"] += current_bet
                current_bet = 0
                dealer_hand = []
                call_or_quit()


            elif hand_value(hand) > 21:
                    print(f"Dealer busted. You win {current_bet * 2} chips!\n")
                    player["chips"] += current_bet * 2
                    print(f"Your current balance is {player['chips']} chips.\n")
                    current_bet = 0
                    dealer_hand = []
                    call_or_quit()

            else:
                print("NOT RIGHT")
                exit()


    #Function to pick a new card
    def pick_card(hand):
        hand.append(deck.pop())
        return hand

    #Function for hit or stand
    def hit_or_stand(hand):
        global current_bet, pscore, dealer_hand
        while True:
            choice = input("\nTo hit, press 1.\nTo stand, press 2.\n")
            if choice == "1":
                pick_card(hand)
                display_hand(hand)
                if hand_value(hand) > 21:
                    print(f"You busted!\nYou've lost {current_bet} chips this round")
                    print(f"\nYour current balance is {player['chips']} chips")
                    check_balance()
                    current_bet = 0
                    call_or_quit()

                elif hand_value(hand) == 21:
                    print(f"You've got BlackJack!'\n{current_bet * 4} chips has been added to your balance.")
                    player["chips"] += current_bet * 4
                    print(f"\nYour current balance is {player['chips']} chips")
                    current_bet = 0
                    call_or_quit()

                else:
                    continue
            elif choice == "2":
                pscore = hand_value(player_hand)
                if dealer_hand == []:
                    dealer_hand = [deck.pop(-1), deck.pop(-1)]
                else:
                    pass
                dealer_turn(dealer_hand)
            else:
                print("Please enter either 1 or 2.")


    # Create a new deck shuffeled deck
    def newdeck():
        global deck, genres, values
        deck = [{"genre": genre, "value": value} for genre in genres for value in values]
        random.shuffle(deck)
        print("\nCards are returned to the deck and deck is shuffeled for a new round")
        return deck


    # Call or quit
    def call_or_quit():
        check_balance()
        global player_hand, dealer_hand, deck
        yn = input("Do you wish to play another round?\nEnter 'y' for yes.\nEnter 'n' for no.\n")
        if yn.lower() == "y":
            player_hand = []
            dealer_hand = []
            newdeck()
            player_bet()
            input("Dealer deals the cards in circle.\nYou get two cards and so does the dealer\nPress enter to continue...\n")
            player_hand = [deck.pop(-1), deck.pop(-1)]
            dealer_hand = [deck.pop(-1), deck.pop(-1)]
            print("You flip your cards and..")
            display_hand(player_hand)
            if hand_value(player_hand) == 21:
                print(f"You've got BlackJack!'\n{current_bet * 4} chips has been added to your balance.")
                player["chips"] += current_bet * 4
                print(f"\nYour current balance is {player['chips']} chips")
                current_bet = 0
            else:
                pass
            display_dealer_hand(dealer_hand)
            hit_or_stand(player_hand)

        elif yn == "n":
            if player["chips"] > 100:
                print(f"In this game you won {player['chips'] - 100} chips. Well done!")
                print("Thanks for playing!")
                exit()
            else:
                print(f"In this game you lost {100 - player['chips']} chips. Better luck next time.")
                print("Thanks for playing!")
                exit()

    #**************************GAME START*******************************

    try:
        player = register(input("Your name:\n"), int(input("Your age:\n")))
    except ValueError:
        print("Your age should be a whole number")
        exit()
    else:
        pass
    playername = player["name"]
    playerage = player["age"]
    if playerage < 18:
        print("I'm sorry, but it seems you'll have to wait a little longer to play this game.")
        exit()
    else:
        pass
    print(f"Welcome to BlackJack {playername}!\nYou've been given 100 chips to start with\nGood luck!\n")
    input("Press enter to start\n")
    player_bet()
    print("\nDealer shuffles the deck")
    shuffle_deck()
    input("Dealer deals the cards in circle.\nYou get two cards and so does the dealer\nPress enter to continue...\n")
    player_hand = [deck.pop(-1), deck.pop(-1)]
    dealer_hand = [deck.pop(-1), deck.pop(-1)]
    print("You flip your cards and..")
    display_hand(player_hand)
    if hand_value(player_hand) == 21:
        print(f"You've got BlackJack!'\n{current_bet * 4} chips has been added to your balance.")
        player["chips"] += current_bet * 4
        print(f"\nYour current balance is {player['chips']} chips")
        current_bet = 0
    else:
        pass

    display_dealer_hand(dealer_hand)
    hit_or_stand(player_hand)
except Exception as e:
    print(e)
    exit()
