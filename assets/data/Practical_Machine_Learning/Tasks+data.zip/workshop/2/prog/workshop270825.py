
import pandas as pd
from sklearn.model_selection import 

df = pd.read_csv("..\..\..\git\itf31519_2025\data\heart_failure\heart_failure_clinical_records_dataset.csv").astype('category')
df.head()

#Random sampling
train = df.sample(frac=0.8)
test = df.drop(train.index)
#Stratified sampling
train = df.groupby('DEATH_EVENT', group_keys=False)[df.columns].sample(frac=0.8)
test = df.drop(train.index)


print(train['DEATH_EVENT'].value_counts()/train.shape[0])
print(test['DEATH_EVENT'].value_counts()/test.shape[0])