
import pandas as pd

data_frame = pd.read_csv('data/dataset.csv').astype('category')
print (data_frame)

feature_frame = data_frame[['Outlook','Temperature','Humidity','Wind']]
target_series = data_frame['Play?']


categorical_feature_frame = pd.get_dummies(feature_frame)

print(categorical_feature_frame)
print(target_series)

from sklearn.tree import DecisionTreeClassifier
from sklearn.tree import plot_tree
import matplotlib.pyplot as plt

classifier = DecisionTreeClassifier()
classifier.fit(categorical_feature_frame, target_series)

plt.figure(figsize=(10, 10))
plot_tree(classifier)

accuracy = classifier.score(categorical_feature_frame, target_series)
print(f'The accuracy of the classifier on training data is: {str(accuracy)}')

print(classifier.predict(categorical_feature_frame))
plt.show()