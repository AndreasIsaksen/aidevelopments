package no.hiof.andreis.models;

public abstract class CelestialBody {
    protected String name;
    protected double radius;
    protected double mass;

// Konstant
    protected static final double gravitationalConstant = 6.67408E-11;

// Konstruktør
    public CelestialBody(String name, double radius, double mass) {
        this.name = name;
        this.radius = radius;
        this.mass = mass;
    }

// toString
    @Override
    public String toString() {
        return "CelestialBody:" +
                "\nname: " + name +
                "\nradius" + radius +
                "\nmass: " + mass;
    }

// Settere
    public void setName() {
        this.name = name;
    }
    public void  setRadius() {
        this.radius = radius;
    }
    public void setMass() {
        this.mass = mass;
    }


// Gettere
    public String getName() {
        return name;
    }
    public double getRadius() {
        return radius;
    }
    public double getMass() {
        return mass;
    }

// Abstrakte metoder
    public abstract double getRadiusInKm();

    public abstract double getMassInKg();

    public abstract double surfaceGravity();



}
