package no.hiof.andreis.models;

public class Star extends CelestialBody{
    protected int effectiveTemp;

// Oppgave 2.3 - Konstanter
// Her deklarerer jeg de konstante verdiene
// Disse er nå satt inn i metodene getRadiusInKm() og getMassInKg()
// Rjup i km
    protected static final double RsunInKm = 695_700;
// Mjup i kg
    protected static final double MsunInKg = 1.98892E30;

// Konstruktør
    public Star(String name, double radius, double mass,
                int effectiveTemp) {
        super(name, radius, mass);
        this.effectiveTemp = effectiveTemp;
    }

// toString
    @Override
    public String toString() {
        return "Star:" +
                "\nname: " + name +
                "\nradius: " + radius +
                "\nmass: " + mass +
                "\neffectiveTemp" + effectiveTemp;
    }

// Settere
    public void setEffectiveTemp() {
        this.effectiveTemp = effectiveTemp;
    }

// Gettere
    public int getEffectiveTemp() {
        return effectiveTemp;
    }

// Konverter
    @Override
    public double getRadiusInKm() {
        return radius * RsunInKm;
    }

    @Override
    public double getMassInKg() {
        return mass * MsunInKg;
    }

// Surface gravity calculator
    @Override
    public double surfaceGravity() {
        return gravitationalConstant * this.getMassInKg() / Math.pow(this.getRadiusInKm() * 1000, 2);
    }

}
