package no.hiof.andreis.models;

public abstract class NaturalSatellite extends CelestialBody{
    protected double semiMajorAxis;
    protected double eccentricity;
    protected int orbitalPeriod;


// Konstant
    protected static final int oneAU = 149_597_871;

// Konstruktør
    public NaturalSatellite(String name, double radius, double mass) {
        super(name, radius, mass);
    }
    public NaturalSatellite(String name, double radius, double mass,
                            double semiMajorAxis, double eccentricity, int orbitalPeriod) {
        super(name, radius, mass);
        this.semiMajorAxis = semiMajorAxis;
        this.eccentricity = eccentricity;
        this.orbitalPeriod = orbitalPeriod;
    }

// toString
    @Override
    public String toString() {
        return "NaturalSatellite:" +
                "\nname: " + name +
                "\nradius: " + radius +
                "\nmass: " + mass +
                "\nsemiMajorAxis: " + semiMajorAxis +
                "\neccentricity: " + eccentricity +
                "\norbitalPeriod: " + orbitalPeriod;
    }

// Settere
    public void setSemiMajorAxis() {
        this.semiMajorAxis = semiMajorAxis;
    }

    public void setEccentricity() {
        this.eccentricity = eccentricity;
    }

    public void setOrbitalPeriod() {
        this.orbitalPeriod = orbitalPeriod;
    }

// Gettere
    public double getSemiMajorAxis() {
        return semiMajorAxis;
    }

    public double getEccentricity() {
        return eccentricity;
    }

    public int getOrbitalPeriod() {
        return orbitalPeriod;
    }


// Oppgave 2.6 a)
    public double distanceToCentralBody(double degrees) {
        double r = (this.semiMajorAxis * (1 - Math.pow(this.eccentricity, 2))) /
                (1 + this.eccentricity * Math.cos(Math.toRadians(degrees)));
        return r * oneAU;
    }
    public String distanceToCentralBodyString(double degrees) {
        double r = (this.semiMajorAxis * (1 - Math.pow(this.eccentricity, 2))) /
                (1 + this.eccentricity * Math.cos(Math.toRadians(degrees)));
        return "Earth has a distance of " + (int)(r * oneAU) +
                "km to the Sun at " + (int)degrees + " degrees";
    }

    public abstract double orbitingVelocity(double distance);
    public abstract String orbitingVelocityString(double distance);


}
