package no.hiof.andreis.models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class PlanetSystem {
    protected String name;
    protected Star centerStar;
    protected ArrayList<Planet> planets;

// Konstruktør

    public PlanetSystem(String name, Star centerStar, ArrayList<Planet> planets) {
        this.name = name;
        this.centerStar = centerStar;
        this.planets = planets;
    }

// toString
    @Override
    public String toString() {
        return "PlanetSystem:" +
                "\nname: " + name +
                "\ncenterStar: " + centerStar +
                "\nplanets: " + planets;
    }

//Settere
    public void setName() {
        this.name = name;
    }
    public void setCenterStar() {
        this.centerStar = centerStar;
    }
    public void setPlanets() {
        this.planets = planets;
    }


// Gettere
    public String getName() {
        return name;
    }
    public Star getCenterStar() {
        return centerStar;
    }

    public ArrayList<Planet> getPlanets() {
        return this.planets = planets;
    }


// Sort planets by radius and mass
    public List<String> getSortedPlanets() {
        List<Planet> sortedPlanets = new ArrayList<>(planets);

        Comparator<Planet> planetComparator = Comparator
                .comparingDouble(Planet::getRadius)
                .thenComparingDouble(Planet::getMass);

        Collections.sort(sortedPlanets, planetComparator);

        List<String> sortedPlanetsList = new ArrayList<>();
        for (Planet planet : sortedPlanets) {
            sortedPlanetsList.add(planet + "\n");
        }

        return sortedPlanetsList;
    }

// Sort planets by radius and mass, but only show planet names
    public List<String> getSortedPlanetNames() {
        List<Planet> sortedPlanets = new ArrayList<>(planets);

        Comparator<Planet> planetComparator = Comparator
                .comparingDouble(Planet::getRadius)
                .thenComparingDouble((Planet::getMass));

        Collections.sort(sortedPlanets, planetComparator);

        List<String> sortedPlanetNames = new ArrayList<>();
        for (Planet planet : sortedPlanets) {
            sortedPlanetNames.add(planet.getName());
        }

        return sortedPlanetNames;
    }

// Oppgave 2.2 - Navn
// Her deklareres en String metode som tar en String som parameter
    public String getPlanetFromList(String planetName) {
// Her kjøres en for-each loop som itererer gjennom alle objekter av Planet klassen i Arraylisten planets
        for (Planet planet : planets) {
// Kroppen til denne for loopen inneholder en if funksjon som sammenligner String verdien i hvert objekt
// med String verdien som blir definert i parameteret('.equalsIgnoreCase' gjør at den ignorerer om det er skrevet med stor eller liten bokstav)
            if (planet.getName().equalsIgnoreCase(planetName)) {
// Om den får en match på String, så returnerer den en String med informasjonen om det gjeldende objektet fra Arraylisten til planets
                return "Name: " + planet.getName() +
                        "\nRadius: " + planet.getRadius() +
                        "\nMass: " + planet.getMass() +
                        "\nSemi major axis: " + planet.getSemiMajorAxis() +
                        "\nEccentricity: " + planet.getEccentricity() +
                        "\nOrbital period: " + planet.getOrbitalPeriod() +
                        "\ncenterStar: " + centerStar.getName();
            }
        }
// Om den ikke får match på String verdien vill den returnere denne String verdien istedet
        return "Can't find planet in this system. Please check your spelling.";
    }


}
