package no.hiof.andreis.models;

public class Planet extends NaturalSatellite{
    protected Star centralCelestialBody;

// Oppgave 2.3 - Konstanter
// Her deklarerer jeg de konstante verdiene
// Disse er nå satt inn i metodene getRadiusInKm() og getMassInKg()
// Rjup i km
    protected static final double RjupInKm = 71_492;
// Mjup i kg
    protected static final double MjupInKg = 1.898E27;

// Konstruktør
    public Planet(String name, double radius, double mass) {
        super(name, radius, mass);
    }
    public Planet(String name, double radius, double mass,
                  double semiMajorAxis, double eccentricity, int orbitalPeriod, Star centralCelestialBody) {
        super(name, radius, mass, semiMajorAxis, eccentricity, orbitalPeriod);
        this.centralCelestialBody = centralCelestialBody;
    }

// toString
    @Override
    public String toString() {
        return "Planet:" +
                "\nname: " + name +
                "\nradius:" + radius +
                "\nmass:" + mass +
                "\nsemiMajorAxis: " + semiMajorAxis +
                "\neccentricity: " + eccentricity +
                "\norbitalPeriod: " + orbitalPeriod +
                "\ncentralCelestialBody: " + centralCelestialBody.getName();
    }

// Settere
    public void setCentralCelestialBody() {
        this.centralCelestialBody = centralCelestialBody;
    }

// Gettere
    public Star getCentralCelestialBody() {
        return centralCelestialBody;
    }

// Konverter
    @Override
    public double getRadiusInKm() {
        return radius * RjupInKm;
    }

    @Override
    public double getMassInKg() {
        return mass * MjupInKg;
    }


// Surface gravity calculator
    @Override
    public double surfaceGravity() {
        return gravitationalConstant * this.getMassInKg() / Math.pow(this.getRadiusInKm() * 1000, 2);
    }

// M-/Rearth converter
    public double toMearth() {
        double earthweight = 5.972E24;
        return this.getMassInKg() / earthweight;
    }

    public double toRearth() {
        double rearth = 6371;
        return this.getRadiusInKm() / rearth;
    }

// Oppgave 2.7 a)
    @Override
    public double orbitingVelocity(double distance) {
        double v = Math.sqrt((gravitationalConstant * centralCelestialBody.getMassInKg())
                / (this.distanceToCentralBody(distance) * 1000));
        return v / 1000;
    }

    @Override
    public String orbitingVelocityString(double distance) {
        double v = Math.sqrt((gravitationalConstant * centralCelestialBody.getMassInKg())
                / (this.distanceToCentralBody(distance) * 1000));
        String removeDecimals = String.format("%.2f", v / 1000);
        return "At a distance of " + (int)this.distanceToCentralBody(distance) +
                "km, Earth has a velocity of " + removeDecimals + "km/s";
    }

}
